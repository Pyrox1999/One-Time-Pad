This program works like this: 
You can first choose between encryption and decryption. 
For encryption, you have to enter a word or text. Then you need a key to encrypt it. Important → The key must be the same length as the word/text. Encryption is done using the XOR operation. 
For decryption, the process is reversed. 

I also use Base64 to properly encode the characters. Base64 works in 6-bit blocks, and to reach a multiple of four characters, padding with "=" is used. That’s why it can happen that you only want to encrypt the word "Hi", but end up with three characters. 

Today, this algorithm is considered laughable, but during World War II, this method was absolutely top-notch!